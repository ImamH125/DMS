package com.edelweiss.bpri.components;

public interface ServiceComponent
{
    public String insert(String jsonData, String... extraParams) throws Exception;
}
