package com.edelweiss.bpri.mailsender;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

@org.springframework.stereotype.Service
public class SendEmail {

	protected static final String host = "zmail.edelcap.com";
	protected String to = null;
	
	protected static String user = null;
	protected static String password = null;
	
	protected Session session = null;

	
	// Get the session object
	/*
	 * Method for sending the mail. feedbackText is a variable which accepts message
	 * body as String
	 */
	public void sendmail(String feedbackType,String feedbackText) {
		try {
			FileReader reader = new FileReader("C:\\resources\\mail.properties");
			//FileReader reader = new FileReader("resources/mail.properties");
			Properties props = new Properties();
			props.load(reader);
			user = props.getProperty("username");
			password = props.getProperty("password");
			to = props.getProperty("toaddress");
			System.out.println("UserName:  " + user);
			//System.out.println("Password: " + password);

			props.put("mail.smtp.host", host);
			props.put("mail.smtp.auth", "true");

			session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(user.trim().toString(), password.trim().toLowerCase());
				}
			});

		} catch (FileNotFoundException f) {
			f.printStackTrace();
		} catch (IOException i) {
			i.printStackTrace();
		}

		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(user));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(to.toString()));
			message.setSubject("Feedback :- "+ feedbackType.toString());
			message.setText(feedbackText.toString());

			// send the message
			Transport.send(message);

			System.out.println("message sent successfully...");

		} catch (MessagingException e) {
			e.printStackTrace();
		}

	}// close of sendmail

}// close of SendEmail
