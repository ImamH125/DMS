'use strict';

var FilterSearchController = angularApp.controller('FilterSearchController',
				function FilterSearchController($scope,$http, $state, $stateParams,
						$rootScope, $location, FilterSearchService,siteId,UtilService) {

					$scope.alfrescoContext = UtilService.alfrescoContextRoot();
					$scope.token = sessionStorage.getItem('token');
					/*$scope.filterValue = 'Products';
					$scope.filterPAValue = 'Reporting And Modelling';
					$scope.filterSPValue = 'Organic Agency';*/
					
					
					$scope.loadIndexDocument = 4;

					// function to increase visible items
					$scope.ViewMore = function(item) {
						// don't increment if at the end of the list
						if (item === 'document') {
							if ($scope.loadIndexDocument < $scope.documentCount) {
								$scope.loadIndexDocument += 4;
								if ($scope.loadIndexDocument >= $scope.allItemsCount) {
									$("#viewmoreId").hide();
								}
							}
						}

					};
					

					/*$scope.marketandproductOnclick = function() {
						
						$state.go('filter-search', {
							term : 'marketandproductOnclick'
						});
		
						}//close of marketandproductOnclick*/	
					
					$scope.productOnclick = function() {
						$state.go('filter-search', {
							term : 'productOnclick'
						});						
					}// close of productOnclick
					
					$scope.marketingOnclick = function() {
						$state.go('filter-search', {
							term : 'marketingOnclick'
						});	
					}// close of marketingOnclick
					$scope.PerformActuarialAnalysisOnclick = function() {
						
						 // alert("I am inside the Perform Actuarial Analysis");
							//$state.go('PA-landing');
						$state.go('filter-search', {
							term : 'PerformActuarialAnalysisOnclick'
						});
						}
					
					$scope.SalesProductsOnclick = function() {
						
						 // alert("I am inside the SalesProductsOnclick");
						$state.go('filter-search', {
							term : 'SalesProductsOnclick'
						});
						}
					$scope.OperationsAndServicesOnclick = function() {
						
						 // alert("I am inside the SalesProductsOnclick");
						$state.go('filter-searchos', {
							term : 'OperationsAndServicesOnclick'
						});
						}
					$scope.ManageInvestmentsOnclick = function() {
						
						 // alert("I am inside the SalesProductsOnclick");
						$state.go('filter-search', {
							term : 'ManageInvestmentsOnclick'
						});
						}
					
					
					$scope.filterCategory = function(categoryFilter){
						var category = categoryFilter.trim();
						var searchTerm = $scope.mainSearchText;
						/* Product start*/
						if (category === 'Product') {
							$scope.selectedMenuItem = 'Product';
						} /*Product End*/
						/*Marketing start*/
						else if (category === 'Marketing') {
							$scope.selectedMenuItem = 'Marketing';
						} /* Marketing end*/
						/* PAA start*/
						else if (category === 'Reporting And Modelling') {
							$scope.selectedMenuItem = 'Reporting And Modelling';
						} else if (category === 'Valuation And Reinsurance') {
							$scope.selectedMenuItem = 'Valuation And Reinsurance';
							/*PAA End*/
							/*SP start*/
						} else if (category === 'Organic Agency') {
							$scope.selectedMenuItem = 'Organic Agency';
						} else if (category === 'Bancassurance') {
							$scope.selectedMenuItem = 'Bancassurance';
						} else if (category === 'Direct Sales') {
							$scope.selectedMenuItem = 'Direct Sales';
						} else if (category === 'CBM') {
							$scope.selectedMenuItem = 'CBM';
						} else if (category === 'Web Sales') {
							$scope.selectedMenuItem = 'Web Sales';
						} else if (category === 'Sales Strategy') {
							$scope.selectedMenuItem = 'Sales Strategy';
						} 
						/*SP end*/
						/*Operations and services start*/
						else if (category === 'Branch Services') {
							$scope.selectedMenuItem = 'Branch Services';
						}else if (category === 'Agent Onboarding') {
							$scope.selectedMenuItem = 'Agent Onboarding';
						}else if (category === 'Commission') {
							$scope.selectedMenuItem = 'Commission';
						}else if (category === 'New Business') {
							$scope.selectedMenuItem = 'New Business';
						}else if (category === 'UnderWriting') {
							$scope.selectedMenuItem = 'UnderWriting';
						}else if (category === 'Policy-Servicing') {
							$scope.selectedMenuItem = 'Policy-Servicing';
						}else if (category === 'Customer Services') {
							$scope.selectedMenuItem = 'Customer Services';
						}else if (category === 'Retention') {
							$scope.selectedMenuItem = 'Retention';
						}else if (category === 'Claims') {
							$scope.selectedMenuItem = 'Claims';
						}/*Operations and services end*/
						/*Manage Investments start*/
						else if (category === 'Investments') {
							$scope.selectedMenuItem = 'Investments';
						}/*Manage Investments end*/
						/*AdminAndFacilities start*/
						else if (category === 'Vendor Management') {
							$scope.selectedMenuItem = 'Vendor Management';
						}else if (category === 'Recovery Of Security Deposit') {
							$scope.selectedMenuItem = 'Recovery Of Security Deposit';
						}else if (category === 'Courier Service Management') {
							$scope.selectedMenuItem = 'Courier Service Management';
						}else if (category === 'Budgeting And Expenditure') {
							$scope.selectedMenuItem = 'Budgeting And Expenditure';
						}else if (category === 'Record Management') {
							$scope.selectedMenuItem = 'Record Management';
						}/*AdminAndFacilities end*/
						/*Risk Management start*/
						else if (category === 'Fraud Risk Management') {
							$scope.selectedMenuItem = 'Fraud Risk Management';
						}else if (category === 'Information Security Process') {
							$scope.selectedMenuItem = 'Information Security Process';
						}else if (category === 'Exception Management') {
							$scope.selectedMenuItem = 'Exception Management';
						}else if (category === 'Cyber Crisis Management') {
							$scope.selectedMenuItem = 'Cyber Crisis Management';
						}/*Risk Management end*/
						/*Finance start*/
						else if (category === 'Taxation') {
							$scope.selectedMenuItem = 'Taxation';
						}else if (category === 'Financial Closing Process') {
							$scope.selectedMenuItem = 'Financial Closing Process';
						}else if (category === 'Cash Management Process') {
							$scope.selectedMenuItem = 'Cash Management Process';
						}else if (category === 'Finance Manual') {
							$scope.selectedMenuItem = 'Finance Manual';
						}else if (category === 'Bank Reconciliation Process') {
							$scope.selectedMenuItem = 'Bank Reconciliation Process';
						}else if (category === 'Travel Management') {
							$scope.selectedMenuItem = 'Travel Management';
						}/*Finance end*/
						/*HumanResources start*/
						/*else if (category === 'Consulation Life Cycle') {
							$scope.selectedMenuItem = 'Consulation Life Cycle';
						}else if (category === 'Employee Termination Process') {
							$scope.selectedMenuItem = 'Employee Termination Process';
						}else if (category === 'Mediclaim') {
							$scope.selectedMenuItem = 'Mediclaim';
						}else if (category === 'Monthly Payroll') {
							$scope.selectedMenuItem = 'Monthly Payroll';
						}else if (category === 'Employee Code Creation Process') {
							$scope.selectedMenuItem = 'Employee Code Creation Process';
						}else if (category === 'Leave Management') {
							$scope.selectedMenuItem = 'Leave Management';
						}else if (category === 'Employee Grievance') {
							$scope.selectedMenuItem = 'Employee Grievance';
						}else if (category === 'Employee Transfer Process') {
							$scope.selectedMenuItem = 'Employee Transfer Process';*/
						else if (category === 'Policies') {
							$scope.selectedMenuItem = 'Policies';
						}else if (category === 'Learning and development') {
							$scope.selectedMenuItem = 'Learning and development';
						}else if (category === 'Forms') {
							$scope.selectedMenuItem = 'Forms';
						}else if (category === 'SOPs') {
							$scope.selectedMenuItem = 'SOPs';
						}/*HumanResources end*/
						/* InformationTechnology start*/
						else if (category === 'IT') {
							$scope.selectedMenuItem = 'IT';
						}else if (category === 'Infra Management Process') {
							$scope.selectedMenuItem = 'Infra Management Process';
						}/* InformationTechnology end*/
						/* LegalAndCompliance start*/
						else if (category === 'Legal') {
							$scope.selectedMenuItem = 'Legal';
						}else if (category === 'Compliance') {
							$scope.selectedMenuItem = 'Compliance';
						}/* LegalAndCompliance end*/
						/*LearningAndDevelopment start*/
						
						/*LearningAndDevelopement end*/
						
						if (searchTerm != undefined && searchTerm != null
								&& searchTerm != '') {
							// searchTerm = searchTerm.trim();
							searchTerm = '*';
						} else {
							searchTerm = '*';
						}

						if (category != 'All') {
							/*
							 * $state.go('category-landing', {
							 * productsAndMarketing : productsAndMarketing, term :
							 * searchTerm });
							 */
						} else {
							$state.go('homeEtlife');
						}
						// close

						FilterSearchService.getFilteredDocuments(searchTerm,categoryFilter,
										function(response) {
											if (response != 'error') {
												$scope.allItemsCount = response.length;
												
												if($scope.allItemsCount<=4){
													$("#viewmoreId").hide();
													
												}else{
													$("#viewmoreId").show();
												}
												
												
												
												$scope.categoryFilter = categoryFilter;
												if (searchTerm != '*') {
													$scope.searchTerm = searchTerm	+ " in ";
												}
												$scope.allItemsDetails = FilterSearchService.getPropertiesOf(response);
											}
										});

					}
									
					
					//start properties
					
					var getPropertiesOf = function(docType) {
						var details = new Array();
						for (var i = 0; i < docType.length; i++) {
							var doc = docType[i];
							if (doc.name != null || doc.properties != null
									|| doc.id != null || doc.name != undefined
									|| doc.properties != undefined
									|| doc.id != undefined || doc.name != ''
									|| doc.properties != '' || doc.id != '') {

								details.push({
											"displayName" : doc.name.slice(0,
													doc.name.lastIndexOf(".")),
											"name" : doc.name,
											"by" : doc.properties["cm:author"] ? doc.properties["cm:author"]
													: '',
											"description" : doc.properties["cm:description"] ? doc.properties["cm:description"]
													: '',
											/*"category" : doc.properties["edcc:Theme"] ? doc.properties["edcc:Theme"]
													: '',*/
											"subCategory" :  doc.properties["etm:Product"] ? doc.properties["etm:Product"]
											: ''|| doc.properties["etm:Marketing"] ? doc.properties["etm:Marketing"]
											: ''|| doc.properties["etm:Actuarial"] ? doc.properties["etm:Actuarial"]
											: ''|| doc.properties["etm:Sales"] ? doc.properties["etm:Sales"]
											: ''|| doc.properties["etm:OperationsAndServices"] ? doc.properties["etm:OperationsAndServices"]
											: ''|| doc.properties["etm:Investments"] ? doc.properties["etm:Investments"]
											: ''|| doc.properties["etm:AdminAndFacilities"] ? doc.properties["etm:AdminAndFacilities"]
											: ''|| doc.properties["etm:RiskManagement"] ? doc.properties["etm:RiskManagement"]
											: ''|| doc.properties["etm:Finance"] ? doc.properties["etm:Finance"]
											: ''|| doc.properties["etm:HRPolicy"] ? doc.properties["etm:HRPolicy"]
											: ''|| doc.properties["etm:InformationTechnology"] ? doc.properties["etm:InformationTechnology"]
											: ''|| doc.properties["etm:LegalAndCompliance"] ? doc.properties["etm:LegalAndCompliance"]
											: '',
											
											/*"sbu" : doc.properties["edcc:sbu"] ? doc.properties["edcc:sbu"]
													: '',*/
											"id" : doc.id
										});
							}
						}
						return details;
					}
					
					//end properties
					var setDetailsOfEachItem = function(segregatedByMime) {
						// count set on UI
						/*$scope.presentationCount = segregatedByMime.presentation.length;
						$scope.videoCount = segregatedByMime.video.length;*/
						$scope.documentCount = segregatedByMime.document.length;

						// setting all data in a variable
						/*$scope.presentationDetails = getPropertiesOf(segregatedByMime.presentation);
						$scope.videoDetails = getPropertiesOf(segregatedByMime.video);*/
						$scope.documentDetails = getPropertiesOf(segregatedByMime.document);
					}

					var segregateDataByMimeType = function(listOfItems) {
						var segregatedByMime = new Array();
						/*var presentation = new Array();
						var video = new Array();*/
						var document = new Array();

						for (var i = 0; i < listOfItems.length; i++) {
							var data = listOfItems[i].entry;
							if (data.content != undefined) {
								var mimeType = data.content.mimeType;
								// ppt
								if (mimeType != ''){
										
									document.push(data);
								}
							}
						}
						segregatedByMime.push({
							/*"presentation" : presentation,
							"video" : video,*/
							"document" : document
						});
						return segregatedByMime;
					}
					var getAllItems = function() {

						var method = 'post';
						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/api/-default-/public/search/versions/1/search";
						var body = {
							"query" : {
								"query" : "SITE:'" + siteId + "' AND (*)", // \"corporate-controller-bpri\"
								"language" : "afts"
							},
							"paging" : {
								"maxItems" : 100,
								"skipCount" : 0
							},
							"include" : [ "properties" ],
							/* "path" */
							/* "aspectNames" */
							"filterQueries" : [ {
								"query" : "TYPE:'cm:content'"
							}, {
								"query" : "-cm:creator:system"
							}, {
								"query" : "-TYPE:'fm:post'"
							} ],
							/*
							 * query specific to site here site ref is for c
							 * BPRI site
							 * "ANCESTOR:\"workspace://SpacesStore/9553fe6f-0c15-4996-928c-dc919b30ab13\""
							 * "query" : "cm:creator:username"
							 */
							"sort" : [ {
								"type" : "FIELD",
								/*"field" : "cm:mimeType", commented by sandeep*/
								"field" : "cm:created",
								/*"field" : "cm:modified", commented by sandeep*/
								/*"ascending" : "true"*/
								"ascending" : "false"
							} ],
							'defaults' : {
								'textAttributes' : [ 'cm:content', 'cm:name',
										'cm:description', 'cm:title' ],
								'defaultFTSOperator' : 'OR',
								'defaultFTSFieldOperator' : 'OR',
								'namespace' : 'cm',
								'defaultFieldName' : '\"/\"'
							}
						};

						var headers = {
							authorization : "Basic "
									+ btoa(sessionStorage.getItem('token'))
						}

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						})
								.then(
										function successCallback(response) {
											if (response.status === 200) {
												if (response.data.list.entries.length > 0) {
													var listOfItems = response.data.list.entries;
													var segregatedByMime = segregateDataByMimeType(listOfItems)[0];
													setDetailsOfEachItem(segregatedByMime);
												} else {
													/*console.log('0 items in repository');*/
												}
											} else {
												/*console.log('response other than 200 status code',response.status);*/
											}
										}, function errorCallback(response) {
											console.log('error');
											$state.go('login');
										});

					}
					
					
					
					
					

					var init = function() {
						getAllItems();
						/*console.log("inside init of Filtersearch controller ++++++++++++++");*/
						var term = $stateParams.term;
						/*console.log("term value ",term);*/
						
						if(term==='productOnclick')
 							{
							/*console.log("Condition Matched for productOnclick");*/
							//$("#menuItem3").hide();
							//("#menuItem4").hide();
							  /*start
							  $("#menuItem1").css("display", "");
						      $("#menuItem2").css("display", "");
						       end
						      $("#menuItem3").css("display", "none");
						      $("#menuItem4").css("display", "none");
						      $("#menuItem5").css("display", "none");
						      $("#menuItem6").css("display", "none");
						      $("#menuItem7").css("display", "none");
						      $("#menuItem8").css("display", "none");
						      $("#menuItem9").css("display", "none");
						      $("#menuItem10").css("display", "none");
						      $("#menuItem11").css("display","none");
						      $("#menuItem12").css("display","none");
						      $("#menuItem13").css("display","none");
						      $("#menuItem14").css("display","none");
						      $("#menuItem15").css("display","none");
						      $("#menuItem16").css("display","none");
						      $("#menuItem17").css("display","none");
						      $("#menuItem18").css("display","none");
						      $("#menuItem19").css("display","none");
						      $("#menuItem20").css("display","none");
						      $("#menuItem21").css("display","none");
						      $("#menuItem22").css("display","none");
						      $("#menuItem23").css("display","none");
						      $("#menuItem24").css("display","none");
						      $("#menuItem25").css("display","none");
						      $("#menuItem26").css("display","none");
						      $("#menuItem27").css("display","none");
						      $("#menuItem28").css("display","none");
						      $("#menuItem29").css("display","none");
						      $("#menuItem30").css("display","none");
						      $("#menuItem31").css("display","none");
						      $("#menuItem32").css("display","none");
						      $("#menuItem33").css("display","none");
						      $("#menuItem34").css("display","none");
						      $("#menuItem35").css("display","none");
						      $("#menuItem36").css("display","none");
						      $("#menuItem37").css("display","none");
						      $("#menuItem38").css("display","none");
						      $("#menuItem39").css("display","none");
						      $("#menuItem40").css("display","none");
						      $("#menuItem41").css("display","none");
						      $("#menuItem42").css("display","none");
						      $("#menuItem43").css("display","none");
						      $("#menuItem44").css("display","none");
						      $("#menuItem45").css("display","none");
						      $("#menuItem46").css("display","none");
						      $("#menuItem47").css("display","none");*/
						      $("#category1").css("display","");
						      $("#category2").css("display","none");
						      $("#category3").css("display","none");
						      $("#category4").css("display","none");
						      $("#category5").css("display","none");
						      $("#category6").css("display","none");
						      $("#category7").css("display","none");
						      $("#category8").css("display","none");
						      $("#category9").css("display","none");
						      $("#category10").css("display","none");
						      $("#category11").css("display","none");
						      $("#category12").css("display","none");
						      
						      $("#slider-left").css("display", "none"); 
							  $("#slider-right").css("display", "none"); 
						      $scope.filterCategory('Product')

						}if(term==='marketingOnclick')
 							{
							/*console.log("Condition Matched for marketingOnclick");*/
							//$("#menuItem3").hide();
							//("#menuItem4").hide();
							  /*start
							  $("#menuItem1").css("display", "");
						      $("#menuItem2").css("display", "");
						       end
						      $("#menuItem3").css("display", "none");
						      $("#menuItem4").css("display", "none");
						      $("#menuItem5").css("display", "none");
						      $("#menuItem6").css("display", "none");
						      $("#menuItem7").css("display", "none");
						      $("#menuItem8").css("display", "none");
						      $("#menuItem9").css("display", "none");
						      $("#menuItem10").css("display", "none");
						      $("#menuItem11").css("display","none");
						      $("#menuItem12").css("display","none");
						      $("#menuItem13").css("display","none");
						      $("#menuItem14").css("display","none");
						      $("#menuItem15").css("display","none");
						      $("#menuItem16").css("display","none");
						      $("#menuItem17").css("display","none");
						      $("#menuItem18").css("display","none");
						      $("#menuItem19").css("display","none");
						      $("#menuItem20").css("display","none");
						      $("#menuItem21").css("display","none");
						      $("#menuItem22").css("display","none");
						      $("#menuItem23").css("display","none");
						      $("#menuItem24").css("display","none");
						      $("#menuItem25").css("display","none");
						      $("#menuItem26").css("display","none");
						      $("#menuItem27").css("display","none");
						      $("#menuItem28").css("display","none");
						      $("#menuItem29").css("display","none");
						      $("#menuItem30").css("display","none");
						      $("#menuItem31").css("display","none");
						      $("#menuItem32").css("display","none");
						      $("#menuItem33").css("display","none");
						      $("#menuItem34").css("display","none");
						      $("#menuItem35").css("display","none");
						      $("#menuItem36").css("display","none");
						      $("#menuItem37").css("display","none");
						      $("#menuItem38").css("display","none");
						      $("#menuItem39").css("display","none");
						      $("#menuItem40").css("display","none");
						      $("#menuItem41").css("display","none");
						      $("#menuItem42").css("display","none");
						      $("#menuItem43").css("display","none");
						      $("#menuItem44").css("display","none");
						      $("#menuItem45").css("display","none");
						      $("#menuItem46").css("display","none");
						      $("#menuItem47").css("display","none");*/
						      $("#category1").css("display","none");
						      $("#category2").css("display","");
						      $("#category3").css("display","none");
						      $("#category4").css("display","none");
						      $("#category5").css("display","none");
						      $("#category6").css("display","none");
						      $("#category7").css("display","none");
						      $("#category8").css("display","none");
						      $("#category9").css("display","none");
						      $("#category10").css("display","none");
						      $("#category11").css("display","none");
						      $("#category12").css("display","none");
						      
						      $("#slider-left").css("display", "none"); 
							  $("#slider-right").css("display", "none"); 
						      $scope.filterCategory('Marketing')

 							}else if (term==='PerformActuarialAnalysisOnclick') {
							/*console.log("Condition Matched for PerformActuarialAnalysisOnclick");*/
							
							 /*$("#menuItem1").css("display", "none");
						      $("#menuItem2").css("display", "none");
						      start
						      $("#menuItem3").css("display", "");
						      $("#menuItem4").css("display", "");
						      end
						      $("#menuItem5").css("display", "none");
						      $("#menuItem6").css("display", "none");
						      $("#menuItem7").css("display", "none");
						      $("#menuItem8").css("display", "none");
						      $("#menuItem9").css("display", "none");
						      $("#menuItem10").css("display", "none");
						      $("#menuItem11").css("display","none");
						      $("#menuItem12").css("display","none");
						      $("#menuItem13").css("display","none");
						      $("#menuItem14").css("display","none");
						      $("#menuItem15").css("display","none");
						      $("#menuItem16").css("display","none");
						      $("#menuItem17").css("display","none");
						      $("#menuItem18").css("display","none");
						      $("#menuItem19").css("display","none");
						      $("#menuItem20").css("display","none");
						      $("#menuItem21").css("display","none");
						      $("#menuItem22").css("display","none");
						      $("#menuItem23").css("display","none");
						      $("#menuItem24").css("display","none");
						      $("#menuItem25").css("display","none");
						      $("#menuItem26").css("display","none");
						      $("#menuItem27").css("display","none");
						      $("#menuItem28").css("display","none");
						      $("#menuItem29").css("display","none");
						      $("#menuItem30").css("display","none");
						      $("#menuItem31").css("display","none");
						      $("#menuItem32").css("display","none");
						      $("#menuItem33").css("display","none");
						      $("#menuItem34").css("display","none");
						      $("#menuItem35").css("display","none");
						      $("#menuItem36").css("display","none");
						      $("#menuItem37").css("display","none");
						      $("#menuItem38").css("display","none");
						      $("#menuItem39").css("display","none");
						      $("#menuItem40").css("display","none");
						      $("#menuItem41").css("display","none");
						      $("#menuItem42").css("display","none");
						      $("#menuItem43").css("display","none");
						      $("#menuItem44").css("display","none");
						      $("#menuItem45").css("display","none");
						      $("#menuItem46").css("display","none");
						      $("#menuItem47").css("display","none");*/
							  $("#category1").css("display","none");
						      $("#category2").css("display","none");
						      $("#category3").css("display","");
						      $("#category4").css("display","none");
						      $("#category5").css("display","none");
						      $("#category6").css("display","none");
						      $("#category7").css("display","none");
						      $("#category8").css("display","none");
						      $("#category9").css("display","none");
						      $("#category10").css("display","none");
						      $("#category11").css("display","none");
						      $("#category12").css("display","none");
						      $("#slider-left").css("display", "none"); 
							  $("#slider-right").css("display", "none"); 
						     // ng-init="filterCategory('Reporting And Modelling')"
						$scope.filterCategory('Reporting And Modelling')
						      
						     // filterCategory('Reporting And Modelling');
							
						}else if (term==='SalesProductsOnclick') {
							
							/*console.log("Condition Matched for SalesProductsOnclick");*/
							  /*$("#menuItem1").css("display", "none");
						      $("#menuItem2").css("display", "none");
						      $("#menuItem3").css("display", "none");
						      $("#menuItem4").css("display", "none");
						      start
						      $("#menuItem5").css("display", "");
						      $("#menuItem6").css("display", "");
						      $("#menuItem7").css("display", "");
						      $("#menuItem8").css("display", "");
						      $("#menuItem9").css("display", "");
						      $("#menuItem10").css("display","");
						      end
						      $("#menuItem11").css("display","none");
						      $("#menuItem12").css("display","none");
						      $("#menuItem13").css("display","none");
						      $("#menuItem14").css("display","none");
						      $("#menuItem15").css("display","none");
						      $("#menuItem16").css("display","none");
						      $("#menuItem17").css("display","none");
						      $("#menuItem18").css("display","none");
						      $("#menuItem19").css("display","none");
						      $("#menuItem20").css("display","none");
						      $("#menuItem21").css("display","none");
						      $("#menuItem22").css("display","none");
						      $("#menuItem23").css("display","none");
						      $("#menuItem24").css("display","none");
						      $("#menuItem25").css("display","none");
						      $("#menuItem26").css("display","none");
						      $("#menuItem27").css("display","none");
						      $("#menuItem28").css("display","none");
						      $("#menuItem29").css("display","none");
						      $("#menuItem30").css("display","none");
						      $("#menuItem31").css("display","none");
						      $("#menuItem32").css("display","none");
						      $("#menuItem33").css("display","none");
						      $("#menuItem34").css("display","none");
						      $("#menuItem35").css("display","none");
						      $("#menuItem36").css("display","none");
						      $("#menuItem37").css("display","none");
						      $("#menuItem38").css("display","none");
						      $("#menuItem39").css("display","none");
						      $("#menuItem40").css("display","none");
						      $("#menuItem41").css("display","none");
						      $("#menuItem42").css("display","none");
						      $("#menuItem43").css("display","none");
						      $("#menuItem44").css("display","none");
						      $("#menuItem45").css("display","none");
						      $("#menuItem46").css("display","none");
						      $("#menuItem47").css("display","none");*/
							$("#category1").css("display","none");
						      $("#category2").css("display","none");
						      $("#category3").css("display","none");
						      $("#category4").css("display","");
						      $("#category5").css("display","none");
						      $("#category6").css("display","none");
						      $("#category7").css("display","none");
						      $("#category8").css("display","none");
						      $("#category9").css("display","none");
						      $("#category10").css("display","none");
						      $("#category11").css("display","none");
						      $("#category12").css("display","none");
						      $("#slider-left").css("display", "none"); 
							  $("#slider-right").css("display", "none");
						      $scope.filterCategory('Organic Agency')
						      
							
						}else if (term==='OperationsAndServicesOnclick') {
							
							/*console.log("Condition Matched for OperationsAndServicesOnclick");*/
							 /* $("#menuItem1").css("display", "none");
						      $("#menuItem2").css("display", "none");
						      $("#menuItem3").css("display", "none");
						      $("#menuItem4").css("display", "none");
						      $("#menuItem5").css("display", "none");
						      $("#menuItem6").css("display", "none");
						      $("#menuItem7").css("display", "none");
						      $("#menuItem8").css("display", "none");
						      $("#menuItem9").css("display", "none");
						      $("#menuItem10").css("display","none");
						      start
						      $("#menuItem11").css("display","");
						      $("#menuItem12").css("display","");
						      $("#menuItem13").css("display","");
						      $("#menuItem14").css("display","");
						      $("#menuItem15").css("display","");
						      $("#menuItem16").css("display","");
						      $("#menuItem17").css("display","");
						      $("#menuItem18").css("display","");
						      $("#menuItem19").css("display","");
						      end
						      $("#menuItem20").css("display","none");
						      $("#menuItem21").css("display","none");
						      $("#menuItem22").css("display","none");
						      $("#menuItem23").css("display","none");
						      $("#menuItem24").css("display","none");
						      $("#menuItem25").css("display","none");
						      $("#menuItem26").css("display","none");
						      $("#menuItem27").css("display","none");
						      $("#menuItem28").css("display","none");
						      $("#menuItem29").css("display","none");
						      $("#menuItem30").css("display","none");
						      $("#menuItem31").css("display","none");
						      $("#menuItem32").css("display","none");
						      $("#menuItem33").css("display","none");
						      $("#menuItem34").css("display","none");
						      $("#menuItem35").css("display","none");
						      $("#menuItem36").css("display","none");
						      $("#menuItem37").css("display","none");
						      $("#menuItem38").css("display","none");
						      $("#menuItem39").css("display","none");
						      $("#menuItem40").css("display","none");
						      $("#menuItem41").css("display","none");
						      $("#menuItem42").css("display","none");
						      $("#menuItem43").css("display","none");
						      $("#menuItem44").css("display","none");
						      $("#menuItem45").css("display","none");
						      $("#menuItem46").css("display","none");
						      $("#menuItem47").css("display","none");*/
							/*  $("#category1").css("display","none");
						      $("#category2").css("display","none");
						      $("#category3").css("display","none");
						      $("#category4").css("display","");
						      $("#category5").css("display","none");
						      $("#category6").css("display","none");
						      $("#category7").css("display","none");
						      $("#category8").css("display","none");
						      $("#category9").css("display","none");
						      $("#category10").css("display","none");
						      $("#category11").css("display","none");
						      $("#category12").css("display","none");
						      $("#slider-left").css("display",""); 
							  $("#slider-right").css("display","");*/
						      $scope.filterCategory('Branch Services')
						     	
						}else if (term==='ManageInvestmentsOnclick') {
								
								/*console.log("Condition Matched for ManageInvestmentsOnclick");*/
								 /* $("#menuItem1").css("display", "none");
							      $("#menuItem2").css("display", "none");
							      $("#menuItem3").css("display", "none");
							      $("#menuItem4").css("display", "none");
							      $("#menuItem5").css("display", "none");
							      $("#menuItem6").css("display", "none");
							      $("#menuItem7").css("display", "none");
							      $("#menuItem8").css("display", "none");
							      $("#menuItem9").css("display", "none");
							      $("#menuItem10").css("display","none");
							      $("#menuItem11").css("display","none");
							      $("#menuItem12").css("display","none");
							      $("#menuItem13").css("display","none");
							      $("#menuItem14").css("display","none");
							      $("#menuItem15").css("display","none");
							      $("#menuItem16").css("display","none");
							      $("#menuItem17").css("display","none");
							      $("#menuItem18").css("display","none");
							      $("#menuItem19").css("display","none");
							      start
							      $("#menuItem20").css("display","");
							      end
							      $("#menuItem21").css("display","none");
							      $("#menuItem22").css("display","none");
							      $("#menuItem23").css("display","none");
							      $("#menuItem24").css("display","none");
							      $("#menuItem25").css("display","none");
							      $("#menuItem26").css("display","none");
							      $("#menuItem27").css("display","none");
							      $("#menuItem28").css("display","none");
							      $("#menuItem29").css("display","none");
							      $("#menuItem30").css("display","none");
							      $("#menuItem31").css("display","none");
							      $("#menuItem32").css("display","none");
							      $("#menuItem33").css("display","none");
							      $("#menuItem34").css("display","none");
							      $("#menuItem35").css("display","none");
							      $("#menuItem36").css("display","none");
							      $("#menuItem37").css("display","none");
							      $("#menuItem38").css("display","none");
							      $("#menuItem39").css("display","none");
							      $("#menuItem40").css("display","none");
							      $("#menuItem41").css("display","none");
							      $("#menuItem42").css("display","none");
							      $("#menuItem43").css("display","none");
							      $("#menuItem44").css("display","none");
							      $("#menuItem45").css("display","none");
							      $("#menuItem46").css("display","none");
							      $("#menuItem47").css("display","none");*/
								 $("#category1").css("display","none");
							      $("#category2").css("display","none");
							      $("#category3").css("display","none");
							      $("#category4").css("display","none");
							      $("#category5").css("display","none");
							      $("#category6").css("display","");
							      $("#category7").css("display","none");
							      $("#category8").css("display","none");
							      $("#category9").css("display","none");
							      $("#category10").css("display","none");
							      $("#category11").css("display","none");
							      $("#category12").css("display","none");
							      $("#slider-left").css("display","none"); 
								  $("#slider-right").css("display","none");
							      $scope.filterCategory('Investments')
							     /*end*/
						}else if (term==='AdminAndFacilitiesOnclick') {
							
							/*console.log("Condition Matched for AdminAndFacilitiesOnclick");*/
							  /*$("#menuItem1").css("display", "none");
						      $("#menuItem2").css("display", "none");
						      $("#menuItem3").css("display", "none");
						      $("#menuItem4").css("display", "none");
						      $("#menuItem5").css("display", "none");
						      $("#menuItem6").css("display", "none");
						      $("#menuItem7").css("display", "none");
						      $("#menuItem8").css("display", "none");
						      $("#menuItem9").css("display", "none");
						      $("#menuItem10").css("display","none");
						      $("#menuItem11").css("display","none");
						      $("#menuItem12").css("display","none");
						      $("#menuItem13").css("display","none");
						      $("#menuItem14").css("display","none");
						      $("#menuItem15").css("display","none");
						      $("#menuItem16").css("display","none");
						      $("#menuItem17").css("display","none");
						      $("#menuItem18").css("display","none");
						      $("#menuItem19").css("display","none");
						      $("#menuItem20").css("display","none");
						      start
						      $("#menuItem21").css("display","");
						      $("#menuItem22").css("display","");
						      $("#menuItem23").css("display","");
						      $("#menuItem24").css("display","");
						      $("#menuItem25").css("display","");
						      end
						      $("#menuItem26").css("display","none");
						      $("#menuItem27").css("display","none");
						      $("#menuItem28").css("display","none");
						      $("#menuItem29").css("display","none");
						      $("#menuItem30").css("display","none");
						      $("#menuItem31").css("display","none");
						      $("#menuItem32").css("display","none");
						      $("#menuItem33").css("display","none");
						      $("#menuItem34").css("display","none");
						      $("#menuItem35").css("display","none");
						      $("#menuItem36").css("display","none");
						      $("#menuItem37").css("display","none");
						      $("#menuItem38").css("display","none");
						      $("#menuItem39").css("display","none");
						      $("#menuItem40").css("display","none");
						      $("#menuItem41").css("display","none");
						      $("#menuItem42").css("display","none");
						      $("#menuItem43").css("display","none");
						      $("#menuItem44").css("display","none");
						      $("#menuItem45").css("display","none");
						      $("#menuItem46").css("display","none");
						      $("#menuItem47").css("display","none");*/
							 $("#category1").css("display","none");
						      $("#category2").css("display","none");
						      $("#category3").css("display","none");
						      $("#category4").css("display","none");
						      $("#category5").css("display","none");
						      $("#category6").css("display","none");
						      $("#category7").css("display","");
						      $("#category8").css("display","none");
						      $("#category9").css("display","none");
						      $("#category10").css("display","none");
						      $("#category11").css("display","none");
						      $("#category12").css("display","none");
						      $("#slider-left").css("display","none"); 
							  $("#slider-right").css("display","none");
						      $scope.filterCategory('Vendor Management')
						     /*end*/
						}else if (term==='RiskManagementOnclick') {
							
							/*console.log("Condition Matched for RiskManagementOnclick");*/
							 /* $("#menuItem1").css("display", "none");
						      $("#menuItem2").css("display", "none");
						      $("#menuItem3").css("display", "none");
						      $("#menuItem4").css("display", "none");
						      $("#menuItem5").css("display", "none");
						      $("#menuItem6").css("display", "none");
						      $("#menuItem7").css("display", "none");
						      $("#menuItem8").css("display", "none");
						      $("#menuItem9").css("display", "none");
						      $("#menuItem10").css("display","none");
						      $("#menuItem11").css("display","none");
						      $("#menuItem12").css("display","none");
						      $("#menuItem13").css("display","none");
						      $("#menuItem14").css("display","none");
						      $("#menuItem15").css("display","none");
						      $("#menuItem16").css("display","none");
						      $("#menuItem17").css("display","none");
						      $("#menuItem18").css("display","none");
						      $("#menuItem19").css("display","none");
						      $("#menuItem20").css("display","none");
						      $("#menuItem21").css("display","none");
						      $("#menuItem22").css("display","none");
						      $("#menuItem23").css("display","none");
						      $("#menuItem24").css("display","none");
						      $("#menuItem25").css("display","none");
						      start
						      $("#menuItem26").css("display","");
						      $("#menuItem27").css("display","");
						      $("#menuItem28").css("display","");
						      $("#menuItem29").css("display","");
						      end
						      $("#menuItem30").css("display","none");
						      $("#menuItem31").css("display","none");
						      $("#menuItem32").css("display","none");
						      $("#menuItem33").css("display","none");
						      $("#menuItem34").css("display","none");
						      $("#menuItem35").css("display","none");
						      $("#menuItem36").css("display","none");
						      $("#menuItem37").css("display","none");
						      $("#menuItem38").css("display","none");
						      $("#menuItem39").css("display","none");
						      $("#menuItem40").css("display","none");
						      $("#menuItem41").css("display","none");
						      $("#menuItem42").css("display","none");
						      $("#menuItem43").css("display","none");
						      $("#menuItem44").css("display","none");
						      $("#menuItem45").css("display","none");
						      $("#menuItem46").css("display","none");
						      $("#menuItem47").css("display","none");*/
							$("#category1").css("display","none");
						      $("#category2").css("display","none");
						      $("#category3").css("display","none");
						      $("#category4").css("display","none");
						      $("#category5").css("display","none");
						      $("#category6").css("display","none");
						      $("#category7").css("display","none");
						      $("#category8").css("display","");
						      $("#category9").css("display","none");
						      $("#category10").css("display","none");
						      $("#category11").css("display","none");
						      $("#category12").css("display","none");
						      $("#slider-left").css("display","none"); 
							  $("#slider-right").css("display","none");
						      $scope.filterCategory('Fraud Risk Management')
						    
						}else if (term==='FinanceOnclick') {
							
							/*console.log("Condition Matched for FinanceOnclick");*/
							  /*$("#menuItem1").css("display", "none");
						      $("#menuItem2").css("display", "none");
						      $("#menuItem3").css("display", "none");
						      $("#menuItem4").css("display", "none");
						      $("#menuItem5").css("display", "none");
						      $("#menuItem6").css("display", "none");
						      $("#menuItem7").css("display", "none");
						      $("#menuItem8").css("display", "none");
						      $("#menuItem9").css("display", "none");
						      $("#menuItem10").css("display","none");
						      $("#menuItem11").css("display","none");
						      $("#menuItem12").css("display","none");
						      $("#menuItem13").css("display","none");
						      $("#menuItem14").css("display","none");
						      $("#menuItem15").css("display","none");
						      $("#menuItem16").css("display","none");
						      $("#menuItem17").css("display","none");
						      $("#menuItem18").css("display","none");
						      $("#menuItem19").css("display","none");
						      $("#menuItem20").css("display","none");
						      $("#menuItem21").css("display","none");
						      $("#menuItem22").css("display","none");
						      $("#menuItem23").css("display","none");
						      $("#menuItem24").css("display","none");
						      $("#menuItem25").css("display","none");
						      $("#menuItem26").css("display","none");
						      $("#menuItem27").css("display","none");
						      $("#menuItem28").css("display","none");
						      $("#menuItem29").css("display","none");
						      start
						      $("#menuItem30").css("display","");
						      $("#menuItem31").css("display","");
						      $("#menuItem32").css("display","");
						      $("#menuItem33").css("display","");
						      $("#menuItem34").css("display","");
						      $("#menuItem35").css("display","");
						      end
						      $("#menuItem36").css("display","none");
						      $("#menuItem37").css("display","none");
						      $("#menuItem38").css("display","none");
						      $("#menuItem39").css("display","none");
						      $("#menuItem40").css("display","none");
						      $("#menuItem41").css("display","none");
						      $("#menuItem42").css("display","none");
						      $("#menuItem43").css("display","none");
						      $("#menuItem44").css("display","none");
						      $("#menuItem45").css("display","none");
						      $("#menuItem46").css("display","none");
						      $("#menuItem47").css("display","none");*/
							$("#category1").css("display","none");
						      $("#category2").css("display","none");
						      $("#category3").css("display","none");
						      $("#category4").css("display","none");
						      $("#category5").css("display","none");
						      $("#category6").css("display","none");
						      $("#category7").css("display","none");
						      $("#category8").css("display","none");
						      $("#category9").css("display","");
						      $("#category10").css("display","none");
						      $("#category11").css("display","none");
						      $("#category12").css("display","none");
						      $("#slider-left").css("display","none"); 
							  $("#slider-right").css("display","none");
						      $scope.filterCategory('Taxation')
						      
						      
						    
						}else if (term==='HumanResourcesOnclick') {
							
							/*console.log("Condition Matched for HumanResourcesOnclick");*/
							 /* $("#menuItem1").css("display", "none");
						      $("#menuItem2").css("display", "none");
						      $("#menuItem3").css("display", "none");
						      $("#menuItem4").css("display", "none");
						      $("#menuItem5").css("display", "none");
						      $("#menuItem6").css("display", "none");
						      $("#menuItem7").css("display", "none");
						      $("#menuItem8").css("display", "none");
						      $("#menuItem9").css("display", "none");
						      $("#menuItem10").css("display","none");
						      $("#menuItem11").css("display","none");
						      $("#menuItem12").css("display","none");
						      $("#menuItem13").css("display","none");
						      $("#menuItem14").css("display","none");
						      $("#menuItem15").css("display","none");
						      $("#menuItem16").css("display","none");
						      $("#menuItem17").css("display","none");
						      $("#menuItem18").css("display","none");
						      $("#menuItem19").css("display","none");
						      $("#menuItem20").css("display","none");
						      $("#menuItem21").css("display","none");
						      $("#menuItem22").css("display","none");
						      $("#menuItem23").css("display","none");
						      $("#menuItem24").css("display","none");
						      $("#menuItem25").css("display","none");
						      $("#menuItem26").css("display","none");
						      $("#menuItem27").css("display","none");
						      $("#menuItem28").css("display","none");
						      $("#menuItem29").css("display","none");
						      $("#menuItem30").css("display","none");
						      $("#menuItem31").css("display","none");
						      $("#menuItem32").css("display","none");
						      $("#menuItem33").css("display","none");
						      $("#menuItem34").css("display","none");
						      $("#menuItem35").css("display","none");
						      start
						      $("#menuItem36").css("display","");
						      $("#menuItem37").css("display","");
						      $("#menuItem38").css("display","");
						      $("#menuItem39").css("display","");
						      $("#menuItem40").css("display","");
						      $("#menuItem41").css("display","");
						      $("#menuItem42").css("display","");
						      $("#menuItem43").css("display","");
						      end
						      $("#menuItem44").css("display","none");
						      $("#menuItem45").css("display","none");
						      $("#menuItem46").css("display","none");
						      $("#menuItem47").css("display","none");*/
							  $("#category1").css("display","none");
						      $("#category2").css("display","none");
						      $("#category3").css("display","none");
						      $("#category4").css("display","none");
						      $("#category5").css("display","none");
						      $("#category6").css("display","none");
						      $("#category7").css("display","none");
						      $("#category8").css("display","none");
						      $("#category9").css("display","none");
						      $("#category10").css("display","");
						      $("#category11").css("display","none");
						      $("#category12").css("display","none");
						      $("#slider-left").css("display","none"); 
							  $("#slider-right").css("display","none");
						      $scope.filterCategory('Policies')
						    
						}else if (term==='InformationTechnologyOnclick') {
							
							/*console.log("Condition Matched for InformationTechnologyOnclick");*/
							 /* $("#menuItem1").css("display", "none");
						      $("#menuItem2").css("display", "none");
						      $("#menuItem3").css("display", "none");
						      $("#menuItem4").css("display", "none");
						      $("#menuItem5").css("display", "none");
						      $("#menuItem6").css("display", "none");
						      $("#menuItem7").css("display", "none");
						      $("#menuItem8").css("display", "none");
						      $("#menuItem9").css("display", "none");
						      $("#menuItem10").css("display","none");
						      $("#menuItem11").css("display","none");
						      $("#menuItem12").css("display","none");
						      $("#menuItem13").css("display","none");
						      $("#menuItem14").css("display","none");
						      $("#menuItem15").css("display","none");
						      $("#menuItem16").css("display","none");
						      $("#menuItem17").css("display","none");
						      $("#menuItem18").css("display","none");
						      $("#menuItem19").css("display","none");
						      $("#menuItem20").css("display","none");
						      $("#menuItem21").css("display","none");
						      $("#menuItem22").css("display","none");
						      $("#menuItem23").css("display","none");
						      $("#menuItem24").css("display","none");
						      $("#menuItem25").css("display","none");
						      $("#menuItem26").css("display","none");
						      $("#menuItem27").css("display","none");
						      $("#menuItem28").css("display","none");
						      $("#menuItem29").css("display","none");
						      $("#menuItem30").css("display","none");
						      $("#menuItem31").css("display","none");
						      $("#menuItem32").css("display","none");
						      $("#menuItem33").css("display","none");
						      $("#menuItem34").css("display","none");
						      $("#menuItem35").css("display","none");
						      $("#menuItem36").css("display","none");
						      $("#menuItem37").css("display","none");
						      $("#menuItem38").css("display","none");
						      $("#menuItem39").css("display","none");
						      $("#menuItem40").css("display","none");
						      $("#menuItem41").css("display","none");
						      $("#menuItem42").css("display","none");
						      $("#menuItem43").css("display","none");
						      start
						      $("#menuItem44").css("display","");
						      $("#menuItem45").css("display","");
						      end
						      $("#menuItem46").css("display","none");
						      $("#menuItem47").css("display","none");*/
							  $("#category1").css("display","none");
						      $("#category2").css("display","none");
						      $("#category3").css("display","none");
						      $("#category4").css("display","none");
						      $("#category5").css("display","none");
						      $("#category6").css("display","none");
						      $("#category7").css("display","none");
						      $("#category8").css("display","none");
						      $("#category9").css("display","none");
						      $("#category10").css("display","none");
						      $("#category11").css("display","");
						      $("#category12").css("display","none");
						      $("#slider-left").css("display","none"); 
							  $("#slider-right").css("display","none");
						      $scope.filterCategory('IT')						    
						}else if (term==='LegalAndComplianceOnclick') {
							
							/*console.log("Condition Matched for LegalAndComplianceOnclick");*/
							  /*$("#menuItem1").css("display", "none");
						      $("#menuItem2").css("display", "none");
						      $("#menuItem3").css("display", "none");
						      $("#menuItem4").css("display", "none");
						      $("#menuItem5").css("display", "none");
						      $("#menuItem6").css("display", "none");
						      $("#menuItem7").css("display", "none");
						      $("#menuItem8").css("display", "none");
						      $("#menuItem9").css("display", "none");
						      $("#menuItem10").css("display","none");
						      $("#menuItem11").css("display","none");
						      $("#menuItem12").css("display","none");
						      $("#menuItem13").css("display","none");
						      $("#menuItem14").css("display","none");
						      $("#menuItem15").css("display","none");
						      $("#menuItem16").css("display","none");
						      $("#menuItem17").css("display","none");
						      $("#menuItem18").css("display","none");
						      $("#menuItem19").css("display","none");
						      $("#menuItem20").css("display","none");
						      $("#menuItem21").css("display","none");
						      $("#menuItem22").css("display","none");
						      $("#menuItem23").css("display","none");
						      $("#menuItem24").css("display","none");
						      $("#menuItem25").css("display","none");
						      $("#menuItem26").css("display","none");
						      $("#menuItem27").css("display","none");
						      $("#menuItem28").css("display","none");
						      $("#menuItem29").css("display","none");
						      $("#menuItem30").css("display","none");
						      $("#menuItem31").css("display","none");
						      $("#menuItem32").css("display","none");
						      $("#menuItem33").css("display","none");
						      $("#menuItem34").css("display","none");
						      $("#menuItem35").css("display","none");
						      $("#menuItem36").css("display","none");
						      $("#menuItem37").css("display","none");
						      $("#menuItem38").css("display","none");
						      $("#menuItem39").css("display","none");
						      $("#menuItem40").css("display","none");
						      $("#menuItem41").css("display","none");
						      $("#menuItem42").css("display","none");
						      $("#menuItem43").css("display","none");
						      $("#menuItem44").css("display","none");
						      $("#menuItem45").css("display","none");
						      start
						      $("#menuItem46").css("display","");
						      $("#menuItem47").css("display","");
						      end*/
							  $("#category1").css("display","none");
						      $("#category2").css("display","none");
						      $("#category3").css("display","none");
						      $("#category4").css("display","none");
						      $("#category5").css("display","none");
						      $("#category6").css("display","none");
						      $("#category7").css("display","none");
						      $("#category8").css("display","none");
						      $("#category9").css("display","none");
						      $("#category10").css("display","none");
						      $("#category11").css("display","none");
						      $("#category12").css("display","");
						      $("#slider-left").css("display","none"); 
							  $("#slider-right").css("display","none");
						      $scope.filterCategory('Legal')
						    
						}else if (term==='LearningAndDevelopmentOnclick') {
							
							/*console.log("Condition Matched for LearningAndDevelopmentOnclick");*/
							 /* $("#menuItem1").css("display", "none");
						      $("#menuItem2").css("display", "none");
						      $("#menuItem3").css("display", "none");
						      $("#menuItem4").css("display", "none");
						      $("#menuItem5").css("display", "none");
						      $("#menuItem6").css("display", "none");
						      $("#menuItem7").css("display", "none");
						      $("#menuItem8").css("display", "none");
						      $("#menuItem9").css("display", "none");
						      $("#menuItem10").css("display","none");
						      $("#menuItem11").css("display","none");
						      $("#menuItem12").css("display","none");
						      $("#menuItem13").css("display","none");
						      $("#menuItem14").css("display","none");
						      $("#menuItem15").css("display","none");
						      $("#menuItem16").css("display","none");
						      $("#menuItem17").css("display","none");
						      $("#menuItem18").css("display","none");
						      $("#menuItem19").css("display","none");
						      $("#menuItem20").css("display","none");
						      $("#menuItem21").css("display","none");
						      $("#menuItem22").css("display","none");
						      $("#menuItem23").css("display","none");
						      $("#menuItem24").css("display","none");
						      $("#menuItem25").css("display","none");
						      $("#menuItem26").css("display","none");
						      $("#menuItem27").css("display","none");
						      $("#menuItem28").css("display","none");
						      $("#menuItem29").css("display","none");
						      $("#menuItem30").css("display","none");
						      $("#menuItem31").css("display","none");
						      $("#menuItem32").css("display","none");
						      $("#menuItem33").css("display","none");
						      $("#menuItem34").css("display","none");
						      $("#menuItem35").css("display","none");
						      $("#menuItem36").css("display","none");
						      $("#menuItem37").css("display","none");
						      $("#menuItem38").css("display","none");
						      $("#menuItem39").css("display","none");
						      $("#menuItem40").css("display","none");
						      $("#menuItem41").css("display","none");
						      $("#menuItem42").css("display","none");
						      $("#menuItem43").css("display","none");
						      $("#menuItem44").css("display","none");
						      $("#menuItem45").css("display","none");
						      $("#menuItem46").css("display","none");
						      $("#menuItem47").css("display","none");*/
						      /*start*/
							 $("#category1").css("display","none");
						      $("#category2").css("display","none");
						      $("#category3").css("display","none");
						      $("#category4").css("display","none");
						      $("#category5").css("display","none");
						      $("#category6").css("display","none");
						      $("#category7").css("display","none");
						      $("#category8").css("display","none");
						      $("#category9").css("display","none");
						      $("#category10").css("display","none");
						      $("#category11").css("display","none");
						      $("#category12").css("display","none");
						      /*end*/
						      $("#slider-left").css("display","none"); 
							  $("#slider-right").css("display","none");
						      $scope.filterCategory('none')
						    
						}
						
						}

					angular
							.element(document)
							.ready(
									function() {
										console.log("**********FilterSearchController*******");
										$(this).scrollTop(0);

										if (sessionStorage.getItem('token')) {
											//$scope.selectedMenuItem = 'Products';
											init();
										} else {
											sessionStorage.setItem('redirectUrl', $location.absUrl());
											console.log("FilterSearch Unauthenticated");
											$state.go('login');
										}
									});

					

				})