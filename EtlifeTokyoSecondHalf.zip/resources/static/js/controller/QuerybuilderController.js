var rules_basic = {
	condition : 'AND',
	rules : [ {
		id : 'name',
		operator : 'actual',
	} ]
};

$('#builder-basic').queryBuilder({
	plugins : [ 'bt-tooltip-errors' ],
	filters : [ {
		id : 'name',
		label : 'Name',
		type : 'string',
		operators : [ 'actual', 'contains', 'strict', 'loose' ],
		validation : {
			min : 3
		}
	// ,
	// valueGetter : function(rule) {
	// var value = [];
	// rule.$el.find('.rule-value-container input').each(function() {
	// value.push($(this).val());
	// });
	// return value;
	// }
	}, {
		id : 'father_name',
		label : 'Father\'s Name',
		type : 'string',
		operators : [ 'actual', 'contains', 'strict', 'loose' ],
		validation : {
			min : 3
		}
	// ,
	// valueGetter : function(rule) {
	// var value = [];
	// rule.$el.find('.rule-value-container input').each(function() {
	// value.push($(this).val());
	// });
	// return value;
	// }
	}, {
		id : 'pan_tan_no',
		label : 'PAN / TAN',
		type : 'string',
		operators : [ 'actual', 'strict', 'contains' ],
		validation : {
			min : 3
		}
	// ,
	// valueGetter : function(rule) {
	// var value = [];
	// rule.$el.find('.rule-value-container input').each(function() {
	// value.push($(this).val());
	// });
	// return value;
	// }
	}, {
		id : 'source_system_party_id',
		label : 'Client Code',
		type : 'string',
		operators : [ 'actual', 'contains' ],
		validation : {
			min : 3
		}
	// ,
	// valueGetter : function(rule) {
	// var value = [];
	// rule.$el.find('.rule-value-container input').each(function() {
	// value.push($(this).val());
	// });
	// return value;
	// }
	}, {
		id : 'ucic',
		label : 'UCIC',
		type : 'string',
		operators : [ 'actual', 'contains' ],
		validation : {
			min : 3
		}
	// ,
	// valueGetter : function(rule) {
	// var value = [];
	// rule.$el.find('.rule-value-container input').each(function() {
	// value.push($(this).val());
	// });
	// return value;
	// }
	}, {
		id : 'mobile_no',
		label : 'Mobile No.',
		type : 'string',
		operators : [ 'actual', 'strict', 'contains' ],
		validation : {
			// only 10 digits allowed
			// format : /^(\+\d{1,3}[- ]?)?\d{10}$/
			format : /^[0-9]\d*$/
		}
	// ,
	// valueGetter : function(rule) {
	// var value = [];
	// rule.$el.find('.rule-value-container input').each(function() {
	// value.push($(this).val());
	// });
	// return value;
	// }
	}, {
		id : 'landline_no',
		label : 'Landline No.',
		type : 'string',
		operators : [ 'actual', 'strict', 'contains' ],
		validation : {
			// only 10 digits allowed
			// format : /^(\+\d{1,3}[- ]?)?\d{10}$/
			format : /^[0-9]\d*$/
		}
	// ,
	// valueGetter : function(rule) {
	// var value = [];
	// rule.$el.find('.rule-value-container input').each(function() {
	// value.push($(this).val());
	// });
	// return value;
	// }
	}, {
		id : 'email_id',
		label : 'Email Id',
		type : 'string',
		operators : [ 'actual', 'strict', 'loose', 'contains' ],
		validation : {
			min : 3
		}
	// ,
	// valueGetter : function(rule) {
	// var value = [];
	// rule.$el.find('.rule-value-container input').each(function() {
	// value.push($(this).val());
	// });
	// return value;
	// }
	}, {
		id : 'permanent_address',
		label : 'Permanent Address',
		type : 'string',
		operators : [ 'actual', 'contains', 'strict', 'loose' ],
		validation : {
			min : 3
		}
	// ,
	// valueGetter : function(rule) {
	// var value = [];
	// rule.$el.find('.rule-value-container input').each(function() {
	// value.push($(this).val());
	// });
	// return value;
	// }
	}, {
		id : 'mailing_address',
		label : 'Mailing Address',
		type : 'string',
		operators : [ 'actual', 'contains', 'strict', 'loose' ],
		validation : {
			min : 3
		}
	// ,
	// valueGetter : function(rule) {
	// var value = [];
	// rule.$el.find('.rule-value-container input').each(function() {
	// value.push($(this).val());
	// });
	// return value;
	// }
	}, {
		id : 'aadhar_no',
		label : 'Aadhar No.',
		type : 'string',
		operators : [ 'actual', 'contains', 'strict' ],
		validation : {
			// only 10 digits allowed
			// format : /^(\+\d{1,3}[- ]?)?\d{10}$/
			format : /^[0-9]\d*$/
		}
	// ,
	// valueGetter : function(rule) {
	// var value = [];
	// rule.$el.find('.rule-value-container input').each(function() {
	// value.push($(this).val());
	// });
	// return value;
	// }
	}, {
		id : 'corp_group_name',
		label : 'Corp Group Name',
		type : 'string',
		operators : [ 'actual', 'contains', 'strict', 'loose' ],
		validation : {
			min : 3
		}
	// ,
	// valueGetter : function(rule) {
	// var value = [];
	// rule.$el.find('.rule-value-container input').each(function() {
	// value.push($(this).val());
	// });
	// return value;
	// }
	}, {
		id : 'tin_no',
		label : 'TIN No.',
		type : 'string',
		operators : [ 'actual', 'contains', 'strict' ],
		validation : {
			min : 3
		}
	// ,
	// valueGetter : function(rule) {
	// var value = [];
	// rule.$el.find('.rule-value-container input').each(function() {
	// value.push($(this).val());
	// });
	// return value;
	// }
	}, {
		id : 'cin_no',
		label : 'CIN No.',
		type : 'string',
		operators : [ 'actual', 'contains', 'strict' ],
		validation : {
			min : 3
		}
	// ,
	// valueGetter : function(rule) {
	// var value = [];
	// rule.$el.find('.rule-value-container input').each(function() {
	// value.push($(this).val());
	// });
	// return value;
	// }
	}, {
		id : 'dob_doi',
		label : 'DOB / DOI',
		type : 'date',
		operators : [ 'equal', 'between' ],
		validation : {
			format : 'dd-mm-yyyy'
		},
		plugin : 'datepicker',
		plugin_config : {
			format : 'dd-mm-yyyy',
			todayBtn : 'linked',
			todayHighlight : true,
			autoclose : true,
			orientation : 'bottom auto'
		}
	}, {
		id : 'cluster_id',
		label : 'Cluster Id',
		type : 'string',
		operators : [ 'actual' ],
		validation : {
			min : 3
		}
	// ,
	// valueGetter : function(rule) {
	// var value = [];
	// rule.$el.find('.rule-value-container input').each(function() {
	// value.push($(this).val());
	// });
	// return value;
	// }
	}, {
		id : 'permanent_city',
		label : 'Permanent City',
		type : 'string',
		operators : [ 'actual', 'contains' ],
		validation : {
			min : 3
		}
	// ,
	// valueGetter : function(rule) {
	// var value = [];
	// rule.$el.find('.rule-value-container input').each(function() {
	// value.push($(this).val());
	// });
	// return value;
	// }
	}, {
		id : 'permanent_state',
		label : 'Permanent State',
		type : 'string',
		operators : [ 'actual', 'contains' ],
		validation : {
			min : 3
		}
	// ,
	// valueGetter : function(rule) {
	// var value = [];
	// rule.$el.find('.rule-value-container input').each(function() {
	// value.push($(this).val());
	// });
	// return value;
	// }
	}, {
		id : 'permanent_pincode',
		label : 'Permanent Pincode',
		type : 'string',
		operators : [ 'actual', 'contains' ],
		validation : {
			min : 3
		}
	// ,
	// valueGetter : function(rule) {
	// var value = [];
	// rule.$el.find('.rule-value-container input').each(function() {
	// value.push($(this).val());
	// });
	// return value;
	// }
	}, {
		id : 'mailing_city',
		label : 'Mailing City',
		type : 'string',
		operators : [ 'actual', 'contains' ],
		validation : {
			min : 3
		}
	// ,
	// valueGetter : function(rule) {
	// var value = [];
	// rule.$el.find('.rule-value-container input').each(function() {
	// value.push($(this).val());
	// });
	// return value;
	// }
	}, {
		id : 'mailing_state',
		label : 'Mailing State',
		type : 'string',
		operators : [ 'actual', 'contains' ],
		validation : {
			min : 3
		}
	// ,
	// valueGetter : function(rule) {
	// var value = [];
	// rule.$el.find('.rule-value-container input').each(function() {
	// value.push($(this).val());
	// });
	// return value;
	// }
	}, {
		id : 'mailing_pincode',
		label : 'Mailing Pincode',
		type : 'string',
		operators : [ 'actual', 'contains' ],
		validation : {
			min : 3
		}
	// ,
	// valueGetter : function(rule) {
	// var value = [];
	// rule.$el.find('.rule-value-container input').each(function() {
	// value.push($(this).val());
	// });
	// return value;
	// }
	} ],

	rules : rules_basic
});

$('#btn-reset').on('click', function() {
	$('#builder-basic').queryBuilder('reset');
});

$('#reset').on('click', function() {
	$('#builder-basic').queryBuilder('setRules', rules_basic);
});

// $('#search').on('click', function() {
// var result = $('#builder-basic').queryBuilder('getRules');
//
// if (!$.isEmptyObject(result)) {
// alert(JSON.stringify(result, null, 2));
// }
// });
